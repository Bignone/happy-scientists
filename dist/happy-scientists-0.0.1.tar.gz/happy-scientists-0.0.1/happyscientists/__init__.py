name = "happyscientists"
from .scientistsgenerator import ScientistsGenerator
