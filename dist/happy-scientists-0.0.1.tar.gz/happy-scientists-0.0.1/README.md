# Happy Scientists
Incredible package to generate funny random names
